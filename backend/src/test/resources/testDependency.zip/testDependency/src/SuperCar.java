public class SuperCar extends Car{
    private int horsepower;

    public SuperCar(int hp){
        this.horsepower = hp;
    }

    public void setHorsepower(int horsepower) {
        this.horsepower = horsepower;
    }

    public int getHorsepower() {
        return horsepower;
    }
}
