public class Parking {
    private static SuperCar myCar;
    static private final int number1 = 0;
    final static private int number2 = 1;
    static final private int numebr3 = 2;
    final private static int number4 = 3;
    private final static int number5 = 4;

    public Parking(int k){
        this.myCar = new SuperCar(k);
    }

    public final static void m1(){}
    public static final void m2(){}
    final public static void m3(){}
    final static public void m4(){}
    static public final void m5(){}
    static final public void m6(){}
    
}
