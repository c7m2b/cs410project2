public class Car {
    Brake brake = new Brake();

	public void carFunction(int fuel) {
        int h = 10;
        carFunction2(h);
	}

    private void carFunction2(int hp) {

    }

	public void carFunction3() {
        brake.stop();
	}

	public void hp(int hp) {
	}

	public void test(String t) {
	}
    
}
