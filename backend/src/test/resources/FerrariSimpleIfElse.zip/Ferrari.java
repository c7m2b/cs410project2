import java.util.ArrayList;
import java.util.List;

public class Ferrari {
    private Car car;
    private List<String> testList = new ArrayList<String>();

	public Ferrari() {
        car = new Car();
	}

	public void foo() {
        if (f < 20) {
            car.hp(30);
        } else {

        }
	}
	
	/* Produces
		[{
			"call": [
				[{
					"type": "none",
					"callerClass": "Ferrari",
					"calleeClass": "Car",
					"callerName": "hp"
				}],
				[] <---- this should no appear
			],
			"type": "alt"
		}]
	*/

    private int ferrariFunction() {
        return 0;

    }
}