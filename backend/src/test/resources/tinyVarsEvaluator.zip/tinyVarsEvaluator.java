package ast;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class tinyVarsEvaluator implements tinyVarsVisitor<Integer> {
    private PrintWriter writer; // nothing stops a visitor from having other features

    public tinyVarsEvaluator(String outFilename) throws FileNotFoundException, UnsupportedEncodingException {
        writer = new PrintWriter(outFilename, "UTF-8");
        System.out.println("tinyVarsEvaluator will write evaluated output to file: " + outFilename);
    }

    public void closeFile() {
        writer.close();
    }

    private final Map<String, Integer> environment = new HashMap<>(); // locations of variables
    private final Map<Integer, Integer> memory = new HashMap<>(); // values at locations
    private final Map<String, List<Statement>> procs = new HashMap<>(); // maps procedure names to current body definitions

    public Map<String, Integer> getEnvironment() {
        return environment;
    }
    public Map<Integer, Integer> getMemory() {
        return memory;
    }
    public Map<String, List<Statement>> getProcs() {
        return procs;
    }

    private Integer getFreshLocation() {
        Integer i = Integer.valueOf(0); // or use an int; it will get boxed when needed
        while(environment.containsValue(i)) { // Q. what difference might it make if we used memory.containsKey(i) instead?
            i = i + 1; // unboxing and boxing is automatic
        }
        return i;
    }

    @Override
    public Integer visit(Program p) {
        for (Statement s : p.getStatements()){
            s.accept(this);
        }
        return null; // we only return a value for expressions (EXP); evaluation of programs/statements is via side-effects
    }

    @Override
    public Integer visit(Dec d) {
        System.out.println("Putting " + d.getName() + " into symbol table");
        environment.put(d.getName(),getFreshLocation()); // no value yet
        return null; // we only return a value for expressions (EXP); evaluation of statements is via side-effects
    }

    @Override
    public Integer visit(Set s) {
        Integer result = s.getExp().accept(this);
        System.out.println("Setting " + s.getName() + " to " + result);

        memory.put(environment.get(s.getName()), result);
        return null; // we only return a value for expressions (EXP); evaluation of statements is via side-effects
    }

    @Override
    public Integer visit(Print p) {
        writer.println("PRINTING: " + p.getPrinted().accept(this));
        return null; // we only return a value for expressions (EXP); evaluation of statements is via side-effects
    }

    @Override
    public Integer visit(Name n) {
        return memory.get(environment.get(n.getName())); // lookup: variable -> location -> value
    }

    @Override
    public Integer visit(Number n) {
        return n.getValue(); // Java auto-boxes this int as an Integer object
    }

    @Override
    public Integer visit(AddressOfVar a) {
        return environment.get(a.getName()); // return the location assigned to this variable name
    }

    @Override
    public Integer visit(DereferenceExp d) {
        Integer result = d.getExpToDereference().accept(this);
        return memory.get(result);
    }

    @Override
    public Integer visit(SetDereferenced d) {
        Integer result = d.getExp().accept(this);
        System.out.println("Setting *" + d.getName() + " to " + result);

        Integer location = memory.get(environment.get(d.getName()));
        memory.put(location, result);
        return null; // we only return a value for expressions (EXP); evaluation of statements is via side-effects
    }

    @Override
    public Integer visit(Proc p) {
        procs.put(p.getName(), p.getBodyStatements()); // ok to alias here, since we never change the statements from a procedure's body
        return null; // we only return a value for expressions (EXP); evaluation of statements is via side-effects
    }

    @Override
    public Integer visit(Call c) {
        String procname = c.getName();
        if(!procs.containsKey(procname)) {
            throw new RuntimeException("No procedure definition for called procedure: " + procname);
        }

        // define x to be a fresh variable (to avoid code duplication, we create a "new x;" statement and then evaluate it as normal:
        Dec freshDec = new Dec("x");
        freshDec.accept(this);

        // assign this fresh x the value of the passed parameter to the call:
        int paramValue = c.getParam().accept(this); // Exp nodes evaluate to an Integer value
        memory.put(environment.get("x"), paramValue);
        // alternatively, we could build a statement representing "set x, param" and then evaluate it

        for(Statement s : procs.get(c.getName())) {
            s.accept(this); // evaluate each statement from the procedure body
        }
        return null; // we only return a value for expressions (EXP); evaluation of statements is via side-effects
    }
}
