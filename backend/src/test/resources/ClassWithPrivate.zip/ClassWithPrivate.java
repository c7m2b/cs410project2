package com.program.analysis.app.course;

public class ClassWithPrivate {
	private Long id;
	private String a;
	private String b;

	public ClassWithPrivate() {

	}
	
	private class Test {
		
	}
	
    private enum MyEnum {
        A, B, C;
    }
}
