import java.util.ArrayList;
import java.util.List;

public class Ferrari {
    private Car car;
    private List<String> testList = new ArrayList<String>();

	public Ferrari() {
        car = new Car();
	}

	public void foo() {
        int f = 9;

        switch(f) {
            case 1:
              ferrariFunction();
              break;
            case 2:
              ferrariFunction();
              break;
            default:
              Option.optionalFunction();
        }

        switch(ferrariFunction4()) {
            case 1:
              ferrariFunction();
              break;
            case 2:
              ferrariFunction();
              break;
            default:
              Option.optionalFunction();
        }

        switch(ferrariFunction4()) {
            case 1:
              ferrariFunction();
              break;
            case 2:
              break;
            default:
              Option.optionalFunction();
        }

        switch(ferrariFunction4()) {
            case 1:
              ferrariFunction();
              break;
            case 2:
              ferrariFunction();
              break;
            default:
        }

        switch(f) {
            case 1:
              if (f == 0) {
                  car.carFunction4();
              }
              break;
            case 2:
              car.carFunction5(car.carFunction4());
              break;
            default:
              Option.optionalFunction();
        }
	}

    private int ferrariFunction4() {
        return 0;
    }

    private void ferrariFunction2() {
    }

    private int ferrariFunction() {
        return 0;
    }
}