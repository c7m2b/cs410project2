import java.util.ArrayList;
import java.util.List;

public class Ferrari {
    private Car car;
    private List<String> testList = new ArrayList<String>();

	public Ferrari() {
        car = new Car();
	}

	public void foo() {
        int f = 10;
        car.getBrake().thick();
        while (ferrariFunction() > 10) {

        }

        if (Option.optionalFunction() >= 20) {
            ferrariFunction();
        }

        if (ferrariFunction() >= 20) {
            ferrariFunction();
        }
        System.out.println(car.getBrake());
        System.out.println(car.getBrake().thick());
        if (f < 20) {
            car.hp(30);
        } else if (ferrariFunction() > 9) {
            Option.optionalFunction();
            System.out.println("sad face");
        } else if (car.getBrake().thick()!=0) {
            ferrariFunction();
            car.hp(30);
            System.out.println("sad sad face");
            System.out.println("sad sad sad face");
        } else {
            foo();
        }
	}

    private int ferrariFunction() {
        return 0;
    }
}