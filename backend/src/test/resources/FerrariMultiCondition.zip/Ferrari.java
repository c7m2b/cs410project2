import java.util.ArrayList;
import java.util.List;

public class Ferrari {
    private Car car;
    private List<String> testList = new ArrayList<String>();

	public Ferrari() {
        car = new Car();
	}

	public void foo() {
        new Tire().engage();

        if (f < 20) {
            car.hp(30);
        } else if (f > 10) {
            car.test("test");
        } else if (f > 0) {

        } else if (f > 0) {
            foo();
        } else {
			ferrariFunction();
		}
		
        if (f < 20) {
            car.hp(30);
        } else if (f > 10) {
            car.test("test");
        } else if (f > 0) {

        } else if (f > 0) {
            foo();
        }
	}
	
	/* Produces (Missing extra condition and methods)
		[{
			"call": [
				[{
					"type": "none",
					"callerClass": "Ferrari",
					"calleeClass": "Car",
					"callerName": "hp"
				}],
				[]
			],
			"type": "alt"
		}, {
			"call": [
				[{
					"type": "none",
					"callerClass": "Ferrari",
					"calleeClass": "Car",
					"callerName": "hp"
				}],
				[]
			],
			"type": "alt"
		}]
	*/

    private int ferrariFunction() {
        return 0;

    }
}