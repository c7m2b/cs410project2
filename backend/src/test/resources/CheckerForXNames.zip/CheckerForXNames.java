package ast;

public class CheckerForXNames implements tinyVarsVisitor<String> // return any error message: you may have chosen other return values / types
{

    @Override
    public String visit(Program p) {
        String result = "";
        for (Statement s : p.getStatements()) {
            result += s.accept(this);
        }
        return result;
    }

    @Override
    public String visit(Dec d) {
        if (d.getName().equals("x")) {
            return "Error: manually-declared variables cannot have the reserved name x.\n";
        } else {
            return "";
        }
    }

    @Override
    public String visit(Set s) {
        return ""; // you might also have made a check here that x isn't assigned to: that's great if so, but not a requirement for the question
    }

    @Override
    public String visit(Print p) {
        return ""; // this can't violate our check
    }

    @Override
    public String visit(Proc p) {
        String result = ((p.getName().equals("x")) ? "Error: declared procedures cannot have the reserved name x.\n" : "");
        for (Statement s : p.getBodyStatements()) {
            result += s.accept(this);
        }
        return result;
    }

    @Override
    public String visit(Call c) {
        if (c.getName().equals("x")) {
            return "Error: attempted to call x; procedures cannot have the reserved name x.\n";
        } else {
            return "";
        }
    }

    @Override
    public String visit(Name n) {
        return ""; // this can't violate our check
    }

    @Override
    public String visit(Number n) {
        return ""; // this can't violate our check
    }

    @Override
    public String visit(AddressOfVar a) {
        return ""; // this can't violate our check
    }

    @Override
    public String visit(DereferenceExp d) {
        return ""; // this can't violate our check
    }

    @Override
    public String visit(SetDereferenced s) {
        return ""; // this can't violate our check
    }
}
