import java.util.ArrayList;
import java.util.List;

public class Ferrari {
    private Car car;
    private List<String> testList = new ArrayList<String>();

	public Ferrari() {
        car = new Car();
	}

	public void foo() {
        int f = 10;

        while (f > 10) {
            if (f == 10) {

            }
        }

        while (f > 10) {
            if (f == 10) {
                ferrariFunction();
            }
        }

        if (f > 0) {
            if (f == 10) {

            }
        }


        if (f > 0) {
            if (f == 10) {
                ferrariFunction();
            }
        }

        if (f >= 20) {
            while (f == 10) {

            }
        }


        if (f >= 20) {
            while (f == 10) {
                ferrariFunction();
            }
        }

        this.ferrariFunction();
        this.car.carFunction(f);
        car.carFunction4().start();

        if (f == 1) {
            Option.optionalFunction();
            ferrariFunction();
        }


        while (f > 10) {
            Option.optionalFunction();
            ferrariFunction();
        }

        while (f > 10) {
            if (f == 10) {
                Option.optionalFunction();
                ferrariFunction();
            }
        }
	}

    private int ferrariFunction() {
        return 0;
    }
}