

public class Option {

	public static int optionalFunction() {
		return 0;
	}

}
