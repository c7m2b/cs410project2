import java.util.ArrayList;
import java.util.List;

public class Ferrari {
    private Car car;
    private List<String> testList = new ArrayList<String>();

	public Ferrari() {
        car = new Car();
	}

	public void foo() {
        int f = 10;
        String [] strings = {"11111", "22222", "33333", "44444", "55555"};

        for (String s: strings){
            System.out.println(s);
        }

        int [] ints = new int[]{1, 2, 3};
        for (int i : ints){
            i += this.ferrariFunction();
            System.out.println(i);
            if (i >1) {
                i += 2;
            } else {
                i = this.ferrariFunction();
            }
        }

        for (String str : this.testFunc()){
            System.out.println(str);
        }
	}

	private String [] testFunc(){
        return new String[]{"111", "222", "333"};
    }

    private int ferrariFunction() {
        return 1;
    }

}