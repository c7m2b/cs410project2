public enum Direction 
{
   EAST, WEST, NORTH, SOUTH;
}