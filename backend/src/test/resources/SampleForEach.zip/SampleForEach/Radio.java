public class Radio {
    Sound sound = new Sound();

	public void radioFunction() {
        sound.soundFunction();
	}
}
